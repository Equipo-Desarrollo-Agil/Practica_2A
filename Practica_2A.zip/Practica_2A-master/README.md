## Descripción del juego:


En este juego vas a tomar el rol de *Robertina*, una muchacha la cuál se despierta aturdida en un **laberinto**. Deberás de conseguir salir de allí, pero para ello tienes que encontrar la **llave** que abrirá la puerta final, además de resolver los distintos **enigmas** que irán apareciendo según vayas avanzando en el laberinto.


### Personaje:

Joven muchacha llamada Robertina.

## Planificación del primer sprint 

Hemos elegido estas historias de usuario estimando su realización en el primer sprint. Sus valores asignados por votación han sido:

* Historia de usuario 1: Valor de negocio ∞, Puntos de historia 5
* Historia de usuario 2: Valor de negocio ∞, Puntos de historia 1/2
* Historia de usuario 3: Valor de negocio ∞, Puntos de historia 10
* Historia de usuario 4: Valor de negocio ∞, Puntos de historia 3
* Historia de usuario 5: Valor de negocio ∞, Puntos de historia 13
* Historia de usuario 6: Valor de negocio ∞, Puntos de historia 1
* Historia de usuario 7: Valor de negocio ∞, Puntos de historia 1
* Historia de usuario 8: Valor de negocio 100, Puntos de historia 13
* Historia de usuario 9: Valor de negocio 20, Puntos de historia 10


<img src="Captura de pantalla (99).png">


### [URL DE TABLERO EN TRELLO](https://trello.com/b/9Db6VUtc)
